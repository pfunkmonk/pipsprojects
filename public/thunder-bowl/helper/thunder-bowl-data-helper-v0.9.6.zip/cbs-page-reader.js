(() => {
  "use strict";
  const REQUEST_SOURCE = "thunder-bowl-helper-worker";
  const READER_VERSION = "0.9.6";

  const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();

  function hasContent(pageKind, expectedPlayerNames = []) {
    const tables = [...document.querySelectorAll("table")];
    if (pageKind === "roster") {
      const teamTableCount = tables.filter((table) => /\sPlayers$/.test(clean(table.querySelector("tr")?.innerText))).length;
      return teamTableCount >= 12;
    }
    if (pageKind === "scoring-preview") {
      const body = document.body?.innerText || "";
      const playerLinks = document.querySelectorAll('a[href*="/players/playerpage/"],a[href*="/players/"]');
      const rosterNameHits = expectedPlayerNames.filter((name) => body.includes(name)).length;
      return /Scoring Preview/i.test(body) && (playerLinks.length >= 8 || rosterNameHits >= 8);
    }
    const projectionTable = tables.find((table) => /\bFPTS\b/.test(table.innerText || ""));
    return Boolean(projectionTable?.querySelector('a.playerLink[href*="/players/playerpage/"]'));
  }

  function rosterTables() {
    return [...document.querySelectorAll("table")].map((table) => {
      const heading = clean(table.querySelector("tr")?.innerText);
      const teamName = heading.match(/^(.+?)\s+Players$/)?.[1] || "";
      const rows = [...table.querySelectorAll("tr")].map((row) => {
        const playerLink = [...row.querySelectorAll("a[href]")].find((link) => /playerpage|\/players\/\d+/i.test(link.getAttribute("href") || ""));
        const id = (playerLink?.getAttribute("href") || "").match(/(?:playerpage\/|players\/)(\d+)/i)?.[1] || "";
        return {
          cbsPlayerId: id,
          name: clean(playerLink?.textContent),
          cells: [...row.querySelectorAll("th,td")].map((cell) => clean(cell.innerText || cell.textContent)),
          newsTitles: [...row.querySelectorAll("[title]")].map((element) => element.getAttribute("title")).filter(Boolean),
          markerClasses: [...row.querySelectorAll("[class]")].flatMap((element) => [...element.classList]).filter((name) => /inj|status|question|doubt|out|ir|pup/i.test(name)),
        };
      });
      return { teamName, rows };
    }).filter((table) => table.teamName);
  }

  function schedulePage(cbsOrigin, teamNames) {
    const relevant = /schedule|matchup|scoreboard|scores/i;
    const text = clean(document.body?.innerText || document.body?.textContent || "");
    const tables = [...document.querySelectorAll("table")].map((table) => {
      const headerRows = [...table.querySelectorAll("thead tr")];
      const headerRow = headerRows.at(-1) || table.querySelector("tr");
      // CBS uses two THEAD rows on /schedule/full: the first identifies the
      // period and the second labels Matchups/@/Results. Keep both so the
      // normalizer never loses the period number.
      const headers = (headerRows.length ? headerRows : [headerRow])
        .filter(Boolean)
        .flatMap((row) => [...row.querySelectorAll("th,td")].map((cell) => clean(cell.innerText || cell.textContent)));
      const rows = [...table.querySelectorAll("tbody tr, tr")]
        .filter((row) => row !== headerRow && !headerRows.includes(row))
        .map((row) => [...row.querySelectorAll("th,td")].map((cell) => clean(cell.innerText || cell.textContent)))
        .filter((row) => row.length);
      return { headers, rows };
    }).filter((table) => table.rows.length);
    const blocks = [...new Set([...document.querySelectorAll("tr,li,article,select option,[role='option'],[class*='matchup'],[class*='schedule']")]
      .map((node) => clean(node.innerText || node.textContent))
      .filter((value) => value.length >= 8 && value.length <= 500 && teamNames.filter((name) => value.includes(name)).length === 2))];
    const discovered = new Set();
    const addUrl = (raw, label = "") => {
      try {
        const url = new URL(raw, location.href);
        if (url.origin === cbsOrigin && (relevant.test(clean(label) + " " + url.pathname) || /^week\s*(1[0-8]|[1-9])$/i.test(clean(label)))) discovered.add(url.href);
      } catch {
        // Ignore malformed CBS navigation values.
      }
    };
    for (const link of document.querySelectorAll("a[href]")) addUrl(link.getAttribute("href"), link.textContent);
    for (const option of document.querySelectorAll("select option,[role='option'][data-value]")) {
      const label = clean(option.textContent);
      const value = clean(option.value || option.getAttribute("data-value"));
      const week = label.match(/\bweek\s*(1[0-8]|[1-9])\b/i)?.[1] || (/^(1[0-8]|[1-9])$/.test(value) ? value : null);
      if (/^(?:https?:|\/)/i.test(value)) addUrl(value, label);
      else if (week) {
        const url = new URL(location.href);
        url.searchParams.set("week", week);
        discovered.add(url.href);
      }
    }
    return {
      teamHits: teamNames.filter((name) => text.includes(name)).length,
      page: { url: location.href, title: document.title || "", text: text.slice(0, 250_000), tables, blocks },
      discovered: [...discovered].slice(0, 80),
    };
  }

  function scoringPreviewRows(rosterPlayers) {
    const text = (node) => clean(node?.innerText || node?.textContent);
    const headings = [...document.querySelectorAll("h1,h2,h3,h4,h5,th,header,div,span")];
    const reserveHeading = headings.find((node) => /^reserves?$/i.test(text(node)));
    const reservesTop = reserveHeading?.getBoundingClientRect().top ?? Number.POSITIVE_INFINITY;
    const seen = new Set();
    const rows = [];
    const add = ({ cbsPlayerId, name, node }) => {
      if (!cbsPlayerId || !node) return;
      const rect = node.getBoundingClientRect();
      if (!Number.isFinite(rect.top) || rect.width <= 0 || rect.height <= 0) return;
      const key = cbsPlayerId + "|" + Math.round(rect.top);
      if (seen.has(key)) return;
      seen.add(key);
      rows.push({ cbsPlayerId, name, role: rect.top > reservesTop ? "BENCH" : "STARTER", top: rect.top, left: rect.left });
    };
    for (const link of document.querySelectorAll('a[href*="/players/playerpage/"],a[href*="/players/"]')) {
      const href = link.getAttribute("href") || "";
      add({
        cbsPlayerId: href.match(/(?:playerpage\/|players\/)(\d+)/i)?.[1] || "",
        name: text(link),
        node: link,
      });
    }
    const nameNodes = [...document.querySelectorAll("a,button,span,strong,[class*='player']")];
    for (const player of rosterPlayers) {
      if (rows.some((row) => row.cbsPlayerId === player.cbsPlayerId)) continue;
      const matches = nameNodes.filter((node) => text(node) === player.name && node.getBoundingClientRect().width > 0 && node.getBoundingClientRect().height > 0);
      const node = matches.sort((left, right) => left.children.length - right.children.length || left.getBoundingClientRect().width - right.getBoundingClientRect().width)[0];
      add({ cbsPlayerId: player.cbsPlayerId, name: player.name, node });
    }
    return { rows, pageUrl: location.href, pageTitle: document.title || "" };
  }

  function projectionRows(expectedPosition) {
    const table = [...document.querySelectorAll("table")].find((node) => /FPTS/.test(node.innerText || ""));
    if (!table) return [];
    return [...table.querySelectorAll("tr")].map((row) => {
      const link = row.querySelector('a.playerLink[href*="/players/playerpage/"]');
      const id = (link?.getAttribute("href") || "").match(/playerpage\/(\d+)/)?.[1] || "";
      const identity = link?.getAttribute("aria-label") || "";
      const identityMatch = identity.match(/\s(QB|RB|WR|TE|K|DST)\s+([A-Z]{2,3})\s*$/i);
      return {
        cbsPlayerId: id,
        name: clean(link?.textContent),
        nflTeam: identityMatch?.[1]?.toUpperCase() === expectedPosition ? identityMatch[2].toUpperCase() : "",
        cells: [...row.querySelectorAll("th,td")].map((cell) => clean(cell.innerText || cell.textContent)),
      };
    });
  }

  async function fabPages(expectedWeek, cbsOrigin) {
    const relevant = /fab|waiver|claim|transaction|standings|rules|settings|add-drop/i;
    const paths = [
      "/", "/rules", "/settings", "/standings", "/transactions", "/transactions/add-drop",
      "/transactions/waivers", "/transactions/fab", "/transactions/fab-budget",
      "/transactions/fab-order", "/transactions/report",
    ];
    const queue = new Set(paths.map((path) => new URL(path, cbsOrigin).href));
    for (const link of document.querySelectorAll("a[href]")) {
      try {
        const url = new URL(link.href, location.href);
        if (url.origin === cbsOrigin && relevant.test(clean(link.textContent) + " " + url.pathname)) queue.add(url.href);
      } catch {
        // Ignore malformed CBS navigation links.
      }
    }
    async function fetchPage(requestedUrl) {
      let timeout = null;
      try {
        const controller = new AbortController();
        timeout = setTimeout(() => controller.abort(), 6_000);
        const response = await fetch(requestedUrl, {
          credentials: "include",
          cache: "no-store",
          signal: controller.signal,
          headers: { Accept: "text/html" },
        });
        if (!response.ok || new URL(response.url).origin !== cbsOrigin) return null;
        const html = await response.text();
        if (html.length < 500 || html.length > 3_000_000) return null;
        const documentCopy = new DOMParser().parseFromString(html, "text/html");
        const text = clean(documentCopy.body?.innerText || documentCopy.body?.textContent);
        if (/sign in to continue|forgot your password/i.test(text) && !/Angry Face|Dogs of War|Orange Crush/.test(text)) return null;
        const tables = [...documentCopy.querySelectorAll("table")].map((table) => {
          const headerRow = table.querySelector("thead tr:last-child") || table.querySelector("tr");
          const headers = [...(headerRow?.querySelectorAll("th,td") || [])].map((cell) => clean(cell.textContent));
          const rows = [...table.querySelectorAll("tbody tr, tr")]
            .filter((row) => row !== headerRow)
            .map((row) => [...row.querySelectorAll("th,td")].map((cell) => clean(cell.textContent)))
            .filter((row) => row.length);
          return { headers, rows };
        }).filter((table) => table.rows.length);
        if (!relevant.test((documentCopy.title || "") + " " + response.url + " " + text) && !/Angry Face|Dogs of War|Orange Crush/.test(text)) return null;
        return { url: response.url, title: documentCopy.title || "", text: text.slice(0, 80_000), tables };
      } catch {
        return null;
      } finally {
        if (timeout !== null) clearTimeout(timeout);
      }
    }
    const candidates = [...queue].slice(0, 16);
    const captured = [];
    for (let index = 0; index < candidates.length; index += 8) {
      captured.push(...await Promise.all(candidates.slice(index, index + 8).map(fetchPage)));
    }
    return { week: expectedWeek, pages: captured.filter(Boolean) };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.source !== REQUEST_SOURCE || message?.action !== "read-cbs-page") return false;
    if (message.kind === "fab-pages") {
      fabPages(message.args?.week, message.args?.cbsOrigin)
        .then((value) => sendResponse({ ok: true, readerVersion: READER_VERSION, value }))
        .catch((error) => sendResponse({ ok: false, readerVersion: READER_VERSION, error: error instanceof Error ? error.message : String(error) }));
      return true;
    }
    try {
      const args = message.args || {};
      const value = message.kind === "has-content"
        ? hasContent(args.pageKind, args.expectedPlayerNames)
        : message.kind === "roster-tables"
          ? rosterTables()
          : message.kind === "schedule-page"
            ? schedulePage(args.cbsOrigin, args.teamNames || [])
            : message.kind === "scoring-preview-rows"
              ? scoringPreviewRows(args.rosterPlayers || [])
              : message.kind === "projection-rows"
                ? projectionRows(args.position)
                : null;
      sendResponse({ ok: true, readerVersion: READER_VERSION, value });
    } catch (error) {
      sendResponse({ ok: false, readerVersion: READER_VERSION, error: error instanceof Error ? error.message : String(error) });
    }
    return false;
  });
})();
